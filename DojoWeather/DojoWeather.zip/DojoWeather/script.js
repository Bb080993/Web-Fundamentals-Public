console.log("Hello")

function loadingReport() {
    alert("Loading weather report...")
}

let popUp=document.querySelector("#popUp")
function removePopup() {
    popUp.remove()
}


//I cannot for the life of me figure out the temperature conversion. Any time I even try to have a function below, it tells me the rest of my functions are undefined. They only work again when I delete my celsius to fahrenheit function, so I am going to leave it like this for the moment. I may come back if we learn an easier way to create these functions. I do not feel like I have all the information needed at this time to complete the challenge function, even after watching the solutions video.